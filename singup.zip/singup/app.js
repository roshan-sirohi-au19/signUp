const express = require('express');
const exphbs = require('express-handlebars');
const multer = require('multer');
const bodyParser = require('body-parser');
const res = require('express/lib/response');
const path=require('path');

const PORT= 3000;
const app = express();
app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static('uploads'))

app.engine('hbs', exphbs.engine({
    defaultLayout:'main',
    extname:'.hbs'
}));

app.set('view engine', 'hbs');
let storage = multer.diskStorage({
    destination:(req, file, cb)=>{
        cb(null, path.join(__dirname, "/uploads"));
    },
    filename:(req, file, cb) => {
        fileExtension = file.mimetype.split('/')[1]
        cb(null, file.fieldname+'.'+fileExtension)
    }
})
let upload= multer({storage:storage});

app.get('/sigup',(req, res)=>{
    res.render('sigup');
})
app.post('/profile', upload.single('avtar'),(req, res)=>{
    console.log(req.file)

    let data ={
        name:req.body.Name,
        email:req.body.Email,
        filename:`${req.file.fieldname}.png`
    }
    res.render('profile',data);
})
app.listen(PORT, ()=>{
    console.log(`server listening to port: ${PORT}`);
})